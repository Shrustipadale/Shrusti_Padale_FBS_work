side = float(input("Enter the side of the equilateral triangle: "))
area = (1.732 / 4) * (side * side)
print("Area of the equilateral triangle is:", area)

