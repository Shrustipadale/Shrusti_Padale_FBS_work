print("Enter marks for any five subjects out of 100")
sub1=float (input("Subject1:"))
sub2=float (input("Subject2:"))
sub3=float (input("Subject3:"))
sub4=float (input("Subject4:"))
sub5=float (input("Subject5:"))
total_marks=sub1+sub2+sub3+sub4+sub5
per=(total_marks/500)*100
print("Percentage:",per)