p=int (input("Enter principle amount:"))
t=int (input("Enter time: "))
r=float (input("Enter rate of interest: "))
interest=(p*t*r)/100
print("Simple interest:",interest)