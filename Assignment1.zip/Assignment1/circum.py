radius=int (input("Enter the radius:"))
area=3.14*radius*radius
circum=2*3.14*radius
print("Area of circle: ",area)
print("Circumference of circle: ",circum)