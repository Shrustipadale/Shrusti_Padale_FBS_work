ang1=int (input("Enter angle1:"))
ang2=int (input("Enter angle2:"))
ang3=180-(ang1+ang2)
print("Third Angle:",ang3)