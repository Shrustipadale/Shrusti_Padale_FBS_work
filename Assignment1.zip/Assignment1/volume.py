radius=int (input("Enter the radius: "))
vol=((4/3)*3.14*radius*radius*radius)
print("Volume of sphere: ",vol)
