#find sum of two digit number
num=int (input("Enter the number:"))
a=num//10
b=num%10
c=a+b
print("Sum of digits: ",c)