divd=float(input("Enter Dividend:"))
div=float(input("Enter Divisor:"))
quo=divd/div
rem=divd-(div*quo)
print("Quotient: ",quo)
print("Remainder:",rem)