len=int (input("Enter length of rectangle:"))
bre=int (input("Enter breadth of rectangle:"))
area=len*bre
print("Area of rectangle:",area)