#find the reverse number
num=int(input("Enter the number: "))
a=num//10
b=num%10
rev=b*10+a
print("Reverse number: ",rev)